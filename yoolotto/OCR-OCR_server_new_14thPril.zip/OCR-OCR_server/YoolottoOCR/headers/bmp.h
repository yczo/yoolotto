#ifndef _BMP_H
#define _BMP_H

int writeMonoBMPHeader( FILE *file, int width, int height );

#endif
